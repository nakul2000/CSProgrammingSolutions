 ____ ____   __   ____  _____ _____  ___       ____   ____  ____  ____   ______    ___  ____    _____
|    \    | /  ] /    |/ ___// ___/ /   \     |    \ /    ||    ||    \ |      |  /  _]|    \  / ___/
|  o  )  | /  / |  o  (   \_(   \_ |     |    |  o  )  o  | |  | |  _  ||      | /  [_ |  D  )(   \_ 
|   _/|  |/  /  |     |\__  |\__  ||  O  |    |   _/|     | |  | |  |  ||_|  |_||    _]|    /  \__  |
|  |  |  /   \_ |  _  |/  \ |/  \ ||     |    |  |  |  _  | |  | |  |  |  |  |  |   [_ |    \  /  \ |
|  |  |  \     ||  |  |\    |\    ||     |    |  |  |  |  | |  | |  |  |  |  |  |     ||  .  \ \    |
|__| |____\____||__|__| \___| \___| \___/     |__|  |__|__||____||__|__|  |__|  |_____||__|\_|  \___|
                                                                                                     
															  

DESCRIPTION
-----------------------------------------------------------------------------------------------------
You have been hired by Picasso Painters to write a simple program to estimate the total cost of 
painting the walls of a home.

INPUT SPECIFICATION
-----------------------------------------------------------------------------------------------------
The input file "rooms.txt" contains all input data.  The first line contains the number of rooms to 
be painted, the second line contains the number of coats required, the third line contains the cost 
of paint per square foot, and the remaining lines list the rooms of the house with their length, 
width, and height. All dimensions are specified in feet.

OUTPUT SPECIFICATION
-----------------------------------------------------------------------------------------------------
Output a file called "invoice.txt" which matches the content and formatting of the sample file 
provided.

RESTRICTIONS
-----------------------------------------------------------------------------------------------------
There are no restrictions for this challenge. You can use any language features.