                                                                                              
 _____ _____ _____ ____  _____ _____ _____ _____ _____    _____ _____ __    _____ _____ _____ 
|     |  |  |  _  |    \| __  |  _  |_   _|     |     |  |   __|     |  |  |  |  |   __| __  |
|  |  |  |  |     |  |  |    -|     | | | |-   -|   --|  |__   |  |  |  |__|  |  |   __|    -|
|__  _|_____|__|__|____/|__|__|__|__| |_| |_____|_____|  |_____|_____|_____|\___/|_____|__|__|
   |__|                                                                                       
   
PROBLEM DESCRIPTION
==============================================================================================
Write a program to calculate the roots of a list of quadratic equations.  Your program should
tell the user if a quadratic equation does not have real roots.

INPUT SPECIFICATION
==============================================================================================
The input file "input.txt" contains the coefficients (A, B, and C) for a number of quadratic
equations. The first line of the input file indicates the number of quadratic equations in 
the input file.

OUTPUT SPECIFICATION
==============================================================================================
The sample output file "output.txt" states the roots of each quadratic equation, if it has
real roots.  Your output file should match the smample output as closely as possible.